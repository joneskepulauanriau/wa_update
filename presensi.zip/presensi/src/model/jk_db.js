const mysql = require('mysql2/promise');

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'dbfkip_umrah',
};

async function getConnection() {
  try {
    const connection = await mysql.createConnection(dbConfig);

    // Mengecek koneksi ke database
    await connection.ping();
    console.log('✅ Koneksi ke database berhasil!');

    return connection;
  } catch (error) {
    console.error('❌ Gagal terhubung ke database:', error.message);

    // Opsi: Jika ingin melempar error ke level di atas
    // throw error;

    return null; // Pastikan mengembalikan null jika koneksi gagal
  }
}

module.exports = { getConnection };