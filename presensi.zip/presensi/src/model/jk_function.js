const { Console } = require("console");
const moment = require('moment');

const StringtoDate = (strDate) => {
    const year = strDate.substring(0, 4);
    const month = strDate.substring(4, 6);
    const day = strDate.substring(6, 8);
    
    // Format tanggal menjadi DD-MM-YYYY
    const formatDate = `${day}-${month}-${year}`;
    return formatDate;   
}

const isValidEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
};

const toDatetime = () => {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // 0 = Januari
    const day = String(now.getDate()).padStart(2, '0');
    
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
    const formatted = `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
    return formatted;
}

const getDateDifference = (date1, date2) => {
  
  const strDate1 = DateToWIB(date1);
  const strDate2 = DateToWIB(date2);

  // Ubah format DD/MM/YYYY menjadi YYYY-MM-DD agar dapat diolah oleh Date object
  const [day1, month1, year1] = strDate1.split('/').map(Number);
  const [day2, month2, year2] = strDate2.split('/').map(Number);

  const d1 = new Date(year1, month1 - 1, day1); // month dikurangi 1 karena index bulan dimulai dari 0
  const d2 = new Date(year2, month2 - 1, day2);

  // Hitung selisih dalam milidetik dan ubah ke hari
  const diffTime = d2-d1 //Math.abs(d2 - d1);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  return diffDays;
}

//const a = '02/03/2025';
//const b = '03/03/2025';

//console.log(`Selisih tanggal ${a} dan ${b} adalah ${getDateDifference(a, b)} hari.`);

const convertToDate = (strTgl) => {
  // Ambil bagian tahun, bulan, dan hari dari string
  const yyyymmdd = String(strTgl);
  const year = yyyymmdd.substring(0, 4);
  const month = yyyymmdd.substring(4, 6);
  const day = yyyymmdd.substring(6, 8);

  // Buat objek Date (bulan dikurangi 1 karena index bulan mulai dari 0)
  //return new Date(year, month - 1, day);
  return moment(`${day}/${month}/${year}`, 'DD/MM/YYYY').toDate();
}

//const a = String(20250203);
//const tanggal = convertToDate(a);

//console.log('Tanggal:', tanggal.toLocaleDateString('id-ID')); // Output dalam format Indonesia (DD/MM/YYYY)

function extractDate(isoString) {
  const date = new Date(isoString);
  
  // Ambil tahun, bulan, dan tanggal
  const year = date.getFullYear();
  const month = String(date.getMonth() +1 ).padStart(2, '0'); // +1 karena bulan dimulai dari 0
  const day = String(date.getDate()-1).padStart(2, '0');

  return `${day}/${month}/${year}`; // Format DD-MM-YYYY
}

// Fungsi untuk mendapatkan nama hari dalam bahasa Indonesia
function getIndonesianDayName(date) {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return days[date.getDay()];
}

// Fungsi untuk mendapatkan nama bulan dalam bahasa Indonesia
function getIndonesianMonthName(date) {
  const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  return months[date.getMonth()];
}

// Fungsi untuk mengonversi Date ke format Indonesia (DD/MM/YYYY)
const DateToWIB = (date) => {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Bulan dimulai dari 0
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
}

// Fungsi untuk mengonversi Date ke format lengkap Indonesia (Hari, DD Bulan YYYY HH:mm:ss)
const DateTimeToWIB = (date, timezone = 'WIB') => {
  const dayName = getIndonesianDayName(date);
  const day = String(date.getDate()).padStart(2, '0');
  const monthName = getIndonesianMonthName(date);
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${dayName}, ${day} ${monthName} ${year} ${hours}:${minutes}:${seconds} ${timezone}`;
}

// Fungsi untuk mengonversi Date ke format lengkap Indonesia (Hari, DD Bulan YYYY HH:mm:ss)
const DateTimeIndonesia = (date, timezone = 'WIB') => {
  //const dayName = getIndonesianDayName(date);
  const day = String(date.getDate()).padStart(2, '0');
  //const monthName = getIndonesianMonthName(date);
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Bulan dimulai dari 0  
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${day}-${month}-${year} ${hours}:${minutes}:${seconds} ${timezone}`;
}


function timeDiffToDecimal(a, b) {
  // Konversi waktu menjadi detik
  const toSeconds = (time) => {
      const [hours, minutes, seconds] = time.split(':').map(Number);
      return hours * 3600 + minutes * 60 + seconds;
  };

  // Konversi detik menjadi jam desimal
  const toDecimal = (seconds) => seconds / 3600;

  // Hitung selisih waktu (b - a), bisa negatif
  const diffInSeconds = toSeconds(b) - toSeconds(a);

  return toDecimal(diffInSeconds);
}

function parseDateTime(timeZone = 'Asia/Jakarta') {
  // Waktu saat ini di zona waktu Asia/Jakarta
  const date = new Date();
  const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
  });

  // Format hasil
  const parts = formatter.formatToParts(date);
  const datePart = `${parts.find(p => p.type === 'year').value}-${parts.find(p => p.type === 'month').value}-${parts.find(p => p.type === 'day').value}`;
  const timePart = `${parts.find(p => p.type === 'hour').value}:${parts.find(p => p.type === 'minute').value}:${parts.find(p => p.type === 'second').value}`;

  return { date: datePart, time: timePart };
}

/*
 * Konversi Tanggal dan Waktu menjadi Tanggal Waktu
 * @param {string} tanggal 
 * @param {string} jam
 */
function toDatetimeTz(date, time) {
  const [day, month, year] = date.split('/');
  return new Date(`${year}-${month}-${day}T${time}`);
}

function timeLimit(date) {
  const sysDate = new Date();
  const diffMs = sysDate - date; 
  return diffMs / (1000 * 60 * 60); 
}

/**
* Mencari Teks yang muncul  

*/
const findContent = (content, pola) => {
  // Pastikan content berupa string
  
  if (typeof content === 'object' && content !== null){
    text = Object.entries(content).map(([key, value]) => `${key}=${value}`).join(', ')
}
//  const text = String(content); 
  const strPola = String(pola); 
  
  // Ambil representasi string dari pola regex
  const findClear = strPola.replace(/\//g, '').replace(/gi$/, '');

  // Cari semua kemunculan menggunakan regex
  const result = text.match(pola);
  const contentFound = [];

  if (result) {
    // Simpan posisi kemunculan dalam array
    let match;
    while ((match = pola.exec(text)) !== null) {
      contentFound.push(match.index);
    }

    return {
      'module': 'findContent',
      'length': result.length,
      'position': contentFound,
      'success': true,
      'message': `Konten ${findClear} ditemukan ${result.length} kali dalam teks`,
    };
  } else {
    return {
      'module': 'findContent',
      'length': 0,
      'position': contentFound,
      'success': false,
      'message': `Konten ${findClear} tidak ditemukan dalam teks`,
    };
  }
};

const isJSON = (text) => {
  try {
    JSON.parse(text);
    return false; // Jika berhasil di-parse, berarti JSON valid
  } catch (e) {
    return true; // Jika error, berarti bukan JSON
  }
}

const isValidDate = (date) => {
  // Pola regex untuk format DD-MM-YYYY
  const datePattern = /^([0-2][0-9]|3[0-1])-([0][1-9]|1[0-2])-(\d{4})$/;

  // Cek apakah sesuai dengan pola regex
  if (!datePattern.test(date)) return false;

  // Pisahkan tanggal, bulan, dan tahun
  const [day, month, year] = date.split('-').map(Number);

  // Buat objek Date (bulan di JavaScript dimulai dari 0, jadi perlu dikurangi 1)
  const parsedDate = new Date(year, month - 1, day);

  // Validasi apakah benar-benar tanggal yang sah di kalender
  return (
      parsedDate.getFullYear() === year &&
      parsedDate.getMonth() === month - 1 &&
      parsedDate.getDate() === day
  );
};

module.exports = {StringtoDate, isValidEmail, toDatetime, getDateDifference, convertToDate, extractDate, DateTimeToWIB, DateTimeIndonesia, DateToWIB, timeDiffToDecimal, parseDateTime,
  toDatetimeTz, timeLimit, findContent, isJSON, isValidDate
}