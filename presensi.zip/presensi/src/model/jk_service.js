const { getConnection } = require('./jk_db');

/**
 * Menambah Data ke Table
 * @param {string} table - Tabel yang akan ditambahkan
 * @param {Array} data - Array data yang akan disimpan
 * @param {Array} indexKey - Kunci yang digunakan pada tabel
 * @param {Array} result - Status proses menambah data  
 */

async function insertData(table, data, indexKey) {
    const modul='insertData';
    if (!table || !data || Object.keys(data).length === 0 || Object.keys(indexKey).length === 0) {
        const result={
          'module': modul,  
          'success':false, 
          'message':'Tabel, Data dan indexKey harus ada...',
          'data':{},
        }
        return result;
    }    

    const connection = await getConnection();

    try {

        for (const row of data) {
            const keys = Object.keys(row);
            const values = Object.values(row);
            
            // Buat query untuk mengecek keberadaan data
            const whereClause = indexKey.map(key => `${key} = ?`).join(' AND ');
            const whereValues = indexKey.map(key => row[key]);
            
            //console.log(whereClause, whereValues);

            const [existing] = await connection.execute(
                `SELECT * FROM ${table} WHERE ${whereClause}`,
                whereValues
            );
            
            if (existing.length === 0) {
                // Jika tidak ada, masukkan data baru
                const placeholders = keys.map(() => '?').join(', ');
                const query = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
                const [rows] = await connection.execute(query, values);
                //console.log(`Data ${JSON.stringify(row)} berhasil dimasukkan ke tabel ${table}.`);
                const result ={
                    'module': modul,
                    'success': true,
                    'message': 'Data berhasil ditambahkan...',
                    'data':rows,
                }
                return result;
            } else {
                //console.log(`Data ${JSON.stringify(row)} sudah ada di tabel ${table}, tidak dimasukkan.`);
                const result ={
                    'module': modul,
                    'success': false,
                    'message': 'Data Tidak dapat ditambahkan...',
                    'data':{},
                }
                return result;
            }
        }
        
    } catch (error) {
        const result ={
            'module': modul,
            'success': false,
            'message': error.message || 'Terjadi kesalahan',
            'data':{},
        }
        return result;
    } finally {
        await connection.end();
    }
}

/**
 * Mengupdate Data ke Table
 * @param {string} table - Tabel yang akan diupdate
 * @param {Array} data - Array data yang akan diupdate
 * @param {Array} indexKey - Kunci yang digunakan pada tabel
 * @param {Array} result - Status proses update data  
 */
async function updateData(table, data, indexKey) {
    const modul = 'updateData';
    if (!table || !data || Object.keys(data).length === 0 || Object.keys(indexKey).length === 0) {
        const result={
            'module': modul,  
            'success':false, 
            'message':'Tabel, Data dan indexKey harus ada...',
            'data':{},
          }
          return result;
      }    

    const connection = await getConnection();
    try {
        for (const row of data) {
            const keys = Object.keys(row);
            const values = Object.values(row);

            // Buat query untuk mengecek keberadaan data
            const whereClause = indexKey.map(key => `${key} = ?`).join(' AND ');
            const whereValues = indexKey.map(key => row[key]);
            
            const [existing] = await connection.execute(
                `SELECT * FROM ${table} WHERE ${whereClause}`,
                whereValues
            );
            
            if (existing.length === 0) {
                // Jika tidak ada
                const result={
                    'module': modul,  
                    'success':false, 
                    'message':'Data tidak ditemukan...',
                    'data':{},
                  }
                  return result;
            } else {
                const keys = Object.keys(row).filter(key => !indexKey.includes(key));
                const values = keys.map(key => row[key]);
                
                const whereClause = indexKey.map(key => `${key} = ?`).join(' AND ');
                const whereValues = indexKey.map(key => row[key]);
                
                const setClause = keys.map(key => `${key} = ?`).join(', ');
                const query = `UPDATE ${table} SET ${setClause} WHERE ${whereClause}`;
                
                const [rows] = await connection.execute(query, [...values, ...whereValues]);

                const result={
                    'module': modul,  
                    'success':true, 
                    'message':'Data sudah diupdate...',
                    'data': rows,
                  }
                  return result;
            }
        }
    } catch (error) {
        const result={
            'module': modul,  
            'success': false, 
            'message': error,
            'data':{},
          }
          return result;
      } finally {
        await connection.end();
    }
}

/**
 * Menghapus Data
 * @param {string} table - Tabel yang akan dihapus
 * @param {Array} conditions - Kondisi data yang akan dihapus
 * @param {Array} result - Status proses hapus data  
 */
async function deleteData(table, conditions) {
    const modul = 'updateData';
    if (!table || Object.keys(conditions).length === 0) {
        const result={
            'module': modul,  
            'success':false, 
            'message':'Tabel, kondisi harus ada...',
            'data':{},
          }
          return result;
      }    

      const connection = await getConnection();

      try {
        const whereClause = Object.keys(conditions).map(key => `${key} = ?`).join(' AND ');
        const whereValues = Object.values(conditions);
                  
        const [existing] = await connection.execute(
                `SELECT * FROM ${table} WHERE ${whereClause}`,
                whereValues
        );
                  
        if (existing.length === 0) {
            // Jika tidak ada
            const result={
                'module': modul,  
                'success':false, 
                'message':'Data tidak ditemukan...',
                'data':{},
            }
            return result;
        }else{
            const query = `DELETE FROM ${table} WHERE ${whereClause}`;

            const [rows] =  await connection.execute(query, whereValues);
    
            const result={
                'module': modul,  
                'success':true, 
                'message':'Data sudah dihapus...',
                'data':rows,
              }
              return result;
        }    
   
    } catch (error) {
        const result={
            'module': modul,  
            'success':true, 
            'message':error,
            'data':{},
          }
          return result;
    } finally {
        await connection.end();
    }
}

/**
 * Mengambil Data Record/Baris
 * @param {string} select - Data yang akan ditampilkan
 * @param {string} table - Tabel yang akan ditampilkan
 * @param {object} where - Kondisi data yang akan ditampilkan boleh null. 
 * @param {Array} row - Data nilai Mahasiswa
 */
async function getDataRow(select, table, where = null) {
    const modul = 'getDataRow';
    const connection = await getConnection();
  
    try {
          let query = `SELECT ${select} FROM ${table}`;
          let values = [];
  
          if (where && typeof where === 'object' && Object.keys(where).length > 0) {
              const whereClauses = Object.keys(where).map(key => `${key} = ?`).join(' AND ');
              query += ` WHERE ${whereClauses}`;
              values = Object.values(where);
          }
  
          //console.log(query, values);

          const [rows] = await connection.execute(query, values);
          let status = rows.length?true:false;  

          const result={
            'module': modul,  
            'success': status, 
            'message': 'Data berhasil dibaca...',
            'data': rows,
          }
          return result;
        } catch (error) {
            const result={
                'module': modul,  
                'success':false, 
                'message':error,
                'data':{},
              }
              return result;
        } finally {
          await connection.end();
        }
  }

  /**
 * Mengambil Data Sesuai Kondisi
 * @param {string} selectColumns - Kolom data yang akan ditampilkan
 * @param {string} tableName - Nama tabel yang akan ditampilkan dapat beberapa tabel dengan JOIN
 * @param {object} whereConditions - Kondisi data yang akan ditampilkan boleh null. 
 * @param {Array} rows - Data nilai yang dihasilkan
 */
/*async function fetchDataWithConditions(selectColumns, tableName, whereConditions = {}) {
    const connection = await getConnection();
    try {
  
        // Pastikan kolom yang dipilih tidak kosong
        if (!selectColumns || selectColumns.length === 0 || !tableName || tableName.length === 0 || Object.keys(conditions).length === 0) {
          throw new Error('Kolom, Tabel dan Kondisi tidak boleh kosong...');
      }
  
      // Susun query SELECT
      let query = `SELECT ${selectColumns.join(', ')} FROM ${tableName} WHERE 1=1`;
      const params = [];
  
      // Tambahkan kondisi WHERE jika ada
      for (const [column, value] of Object.entries(whereConditions)) {
          query += ` AND ${column} = ?`;
          params.push(value);
        }
  
        const [rows] = await connection.execute(query, params);
        //console.table(params);
        return rows;  
      } finally {
        await connection.end();
      }
  }
*/

async function fetchDataWithConditions(selectColumns, tableName, whereConditions = {}) {
    const connection = await getConnection();
    if (connection===null){
      console.log("MySQL Server Belum Aktif...");
      return;
    }
    try {
      // Validasi input
      if (!selectColumns || selectColumns.length === 0) {
        throw new Error('Kolom yang dipilih tidak boleh kosong.');
      }
      if (!tableName || tableName.length === 0) {
        throw new Error('Nama tabel tidak boleh kosong.');
      }
      //if (Object.keys(whereConditions).length === 0) {
      //  throw new Error('Kondisi WHERE tidak boleh kosong.');
      //}
  
      // Susun query SELECT
      let query = `SELECT ${selectColumns.join(', ')} FROM ${tableName} WHERE 1=1`;
      const params = [];


      if (Object.keys(whereConditions).length) {
        // Tambahkan kondisi WHERE
        for (const [column, value] of Object.entries(whereConditions)) {
          query += ` AND ${column} = ?`;
          params.push(value);
      }
    }
  
      const [rows] = await connection.execute(query, params);
      return rows;
    } finally {
      await connection.end();
    }
  }
  
/*
// Contoh penggunaan
const data = [
    { nim: '2103030033', kodemtk: 'AMS', makalah: 85, kehadiran: 100, diskusi: 85, uts: 85 },
    { nim: '2203030001', kodemtk: 'AMS', makalah: 85, kehadiran: 100, diskusi: 85, uts: 89 }
];

insertData('nilaimtk', data, ['nim', 'kodemtk']);

const updatedData = [
    { nim: '2103030033', kodemtk: 'AMS', makalah: 90, kehadiran: 100, diskusi: 90, uts: 90 }
];
updateData('nilaimtk', updatedData, ['nim', 'kodemtk']);

deleteData('nilaimtk', { nim: '2203030001', kodemtk: 'AMS' });
*/

module.exports = {
    insertData, 
    updateData, 
    deleteData,
    getDataRow,
    fetchDataWithConditions
}