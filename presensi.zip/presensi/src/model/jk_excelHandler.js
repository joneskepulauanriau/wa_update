/*
const xlsx = require('xlsx');
const path = require('path');

async function readExcel(fileName, sheetName) {
  const filePath = path.join(__dirname,'../data', fileName);
  const workbook = xlsx.readFile(filePath);
  //const sheetName = workbook.SheetNames[selectSheet]; // Ambil sheet pertama
  const sheet = workbook.Sheets[sheetName];
  return xlsx.utils.sheet_to_json(sheet);
} */

const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs').promises;
  
async function readExcel(fileName, sheetName) {
    try {
      const filePath = path.join(__dirname, '../data', fileName);
      await fs.access(filePath); // Periksa apakah file ada
      const workbook = xlsx.readFile(filePath);
  
      // Validasi nama sheet
      if (!workbook.SheetNames.includes(sheetName)) {
        throw new Error(`Sheet "${sheetName}" tidak ditemukan.`);
      }
  
      const sheet = workbook.Sheets[sheetName];
      return xlsx.utils.sheet_to_json(sheet);
    } catch (error) {
      console.error('Error saat membaca file Excel:', error.message);
      throw error;
    }
}

module.exports = { readExcel };