const {downloadMediaMessage} = require("@whiskeysockets/baileys");
const Jimp = require("jimp-compact");
const QRCode = require("qrcode");
const QRCodeReader = require("qrcode-reader");
const {DateToWIB, isJSON} = require('./jk_function');
//const fs = require("fs");
//const moment = require("moment");


async function readImageQRCode(imagePath) {
    try {
        const image = await Jimp.read(imagePath);
        const qr = new QrCodeReader();

        return new Promise((resolve, reject) => {
            qr.callback = (err, value) => {
                if (err) reject("QR Code tidak dapat dibaca!");
                else resolve(value.result);
            };
            qr.decode(image.bitmap);
        });
    } catch (error) {
        console.error("Terjadi kesalahan:", error);
    }
}

const readQRCode = async (buffer) => {
    try {
        const image = await Jimp.read(buffer);
        const qr = new QRCodeReader();

        return new Promise((resolve, reject) => {
            qr.callback = (err, value) => {
                if (err || !value) return resolve(false);//reject("QR Code tidak ditemukan atau gagal dibaca");
                resolve(value.result);
            };
            qr.decode(image.bitmap);
        });
    } catch (error) {
        throw new Error("Gagal memproses gambar: " + error.message);
    }
};

// Event menangkap pesan gambar dan membaca QR Code
const checkQRCode = async (msg) => {
    if (!msg.message || !msg.message.imageMessage) return;

    try {
        console.log("Menerima gambar berisi QR Code...");

        // Unduh media dalam bentuk buffer
        const buffer = await downloadMediaMessage(msg, "buffer", {});

        // Baca isi QR Code
        const qrResult =  await readQRCode(buffer);
        
        //console.log("Isi QR Code:", qrResult);

        const statJSON = isJSON(qrResult);
        const data ={
            'statusJSON': statJSON,
            'info': qrResult
        }

        return data;

    } catch (error) {
        console.error("Terjadi kesalahan saat membaca QR Code:", error.message);
        //await sock.sendMessage(msg.key.remoteJid, { text: "❌ Gagal membaca QR Code." });
        return;
    }
};

// Buat data unik untuk QR Code (misalnya URL atau teks tertentu)
const generateQRCode = async (data) => {
    //const date = moment().format("YYYY-MM-DD");
    //const presensiData = `PRESENSI-${date}`; // Bisa diganti dengan URL atau data unik

    //console.log(data);

    
    const tgl_kuliah = DateToWIB(data.tgl_kuliah);
    //console.log(tgl_kuliah);
    const tahun = tgl_kuliah.substring(6, 10);
    const bulan =tgl_kuliah.substring(3, 5);
    const hari =tgl_kuliah.substring(0, 2);
    const qrcode_result = `./src/images/PRESENSI-${tahun}${bulan}${hari}${data.id_rencana.toString().padStart(2, '0')}${data.id_kelas}.png`;
    const presensiData = `{'menu':'!presensi', 'id_rencana':${data.id_rencana}, 'id_kelas':${data.id_kelas}, 'tgl_kuliah':'${tgl_kuliah}', 'jam_masuk':'${data.jam_masuk}', 'jam_pulang':'${data.jam_pulang}', 'pertemuan_ke':${data.pertemuan_ke}, 'metode_perkuliahan':'${data.metode_perkuliahan}', 'materi':'${data.materi}'}`;
    //console.log(presensiData);
    //console.log(qrcode_result);

    try {
        // Simpan QR Code sebagai gambar PNG
        await QRCode.toFile(qrcode_result, presensiData);
        return `QR Code berhasil dibuat: "${qrcode_result}"`;
    } catch (err) {
        console.error("Gagal membuat QR Code", err);
    }
/*
    const presensiData = `{'menu':'!presensi', 'id_rencana':${id_rencana}, 'id_kelas':${id_kelas}, 'tgl_kuliah':'${tgl_kuliah}'}`;
    try {
        console.log("📌 Generating QR Code for presensi...");
        const qr = await QRCode.toString(presensiData, { type: "terminal" });
        console.log(qr);

        // Simpan QR Code sebagai gambar PNG
        const qrcode_result = `./src/images/PRESENSI-${tahun}${bulan}${hari}${id_rencana}${id_kelas}.png`
        await QRCode.toFile(qrcode_result, presensiData);
        //console.log(`QR Code berhasil dibuat: "${qrcode_result}"`);
        return `QR Code berhasil dibuat: "${qrcode_result}"`;
    } catch (err) {
        console.error("Gagal membuat QR Code", err);
    }
        */
};

module.exports = {readImageQRCode, checkQRCode, generateQRCode}