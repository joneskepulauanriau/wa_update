const {fetchDataWithConditions} = require('./jk_service');
const {DateToWIB, DateTimeToWIB, DateTimeIndonesia} = require('./jk_function');
const fs = require('fs');
const PDFDocument = require('pdfkit');
const moment = require('moment');

const getPresensi = async (nim) => {
    try {
      const recResult = await fetchDataWithConditions(
        [
          `rencana.pertemuan_ke`,
          `rencana.tgl_kuliah`,
          `rencana.jam_masuk`,
          `rencana.jam_pulang`,
          `presensi.jam_presensi`,
          `presensi.nim`,
          `mahasiswa.nama`,
          `matakuliah.nama_matakuliah`,
          `kelas.kelas`,
          `kelas.tahun_ajaran`,
          `kelas.semester`,
          `kelas.ruang`,
          `matakuliah.sks`,
          `presensi.id_rencana`,
          `rencana.id_kelas`,
          `rencana.metode_perkuliahan`,
          `rencana.materi`,
          `presensi.id_presensi`,
          `mahasiswa.tempat_lahir`,
          `mahasiswa.tgl_lahir`,
          `mahasiswa.jenis_kelamin`,
          `mahasiswa.kode_prodi`,
          `prodi.nama_prodi`,
          `kelas.kode_matakuliah`,
          `kelas.dosen_ketua`,
          `kelas.dosen_anggota`     
        ],
        `presensi
        LEFT OUTER JOIN rencana ON (presensi.id_rencana=rencana.id_rencana)
        INNER JOIN mahasiswa ON (presensi.nim=mahasiswa.nim)
        INNER JOIN prodi ON (mahasiswa.kode_prodi=prodi.kode_prodi)
        INNER JOIN kelas ON (rencana.id_kelas=kelas.id_kelas)
        INNER JOIN matakuliah ON (kelas.kode_matakuliah=matakuliah.kode_matakuliah)`,
        { 'mahasiswa.nim': nim }
      );

      // Validasi jika hasilnya undefined atau null
      if (!recResult || !Array.isArray(recResult)) {
        console.warn("Data presensi tidak ditemukan atau terjadi kesalahan.");
        return [];
      }

      return recResult.map(item => [
        item.pertemuan_ke,
        DateToWIB(item.tgl_kuliah),
        item.jam_masuk,
        item.jam_pulang,
        DateTimeToWIB(item.jam_presensi),
        item.nim,
        item.nama,
        item.nama_matakuliah,
        item.kelas,
        item.tahun_ajaran,
        item.semester,
        item.ruang,
        item.sks,
        item.id_rencana,
        item.id_kelas,
        item.metode_perkuliahan,
        item.materi,
        item.id_presensi,
        item.tempat_lahir,
        item.tgl_lahir,
        item.jenis_kelamin,
        item.kode_prodi,
        item.nama_prodi,
        item.kode_matakuliah,
        item.dosen_ketua,
        item.dosen_anggota     
    ]);

    } catch (error) {
      console.error('Error saat mengambil data presensi:', error);
      return null;
    }
  };

const getDataPresensi = async (id_kelas, tgl_kuliah) => {
  try {
    const tglKuliah = moment(tgl_kuliah, 'DD/MM/YYYY').toDate();
    console.log(tgl_kuliah);
    console.log(tglKuliah);
    const recResult = await fetchDataWithConditions(
      [
        `presensi.id_presensi`,
        `presensi.nim`,
        `mahasiswa.nama`,
        `presensi.jam_presensi`,
        `presensi.id_rencana`,
        `mahasiswa.tempat_lahir`,
        `mahasiswa.tgl_lahir`,
        `mahasiswa.jenis_kelamin`,
        `mahasiswa.kode_prodi`,
        `prodi.nama_prodi`,
        `rencana.id_kelas`,
        `rencana.tgl_kuliah`,
        `rencana.jam_masuk`,
        `rencana.jam_pulang`,
        `rencana.pertemuan_ke`,
        `rencana.metode_perkuliahan`,
        `rencana.materi`,
        `kelas.kode_matakuliah`,
        `kelas.dosen_ketua`,
        `kelas.dosen_anggota`,
        `kelas.kelas`,
        `kelas.tahun_ajaran`,
        `kelas.semester`,
        `kelas.ruang`,
        `matakuliah.nama_matakuliah`,
        `matakuliah.sks`
      ],
      `mahasiswa
      INNER JOIN prodi ON mahasiswa.kode_prodi = prodi.kode_prodi
      INNER JOIN presensi ON mahasiswa.nim = presensi.nim
      INNER JOIN rencana ON presensi.id_rencana = rencana.id_rencana
      INNER JOIN kelas ON rencana.id_kelas = kelas.id_kelas
      INNER JOIN matakuliah ON kelas.kode_matakuliah = matakuliah.kode_matakuliah`,
      { 'rencana.id_kelas': id_kelas, 'rencana.tgl_kuliah': tglKuliah }
    );

    // Validasi jika hasilnya undefined atau null
    if (!recResult || !Array.isArray(recResult)) {
      console.warn("Data presensi tidak ditemukan atau terjadi kesalahan.");
      return [];
    }

    return recResult.map(item => [
      item.id_presensi,
      item.nim,
      item.nama,
      DateTimeIndonesia(item.jam_presensi),
      item.id_rencana,
      item.tempat_lahir,
      item.tgl_lahir,
      item.jenis_kelamin,
      item.kode_prodi,
      item.nama_prodi,
      item.id_kelas,
      DateToWIB(item.tgl_kuliah),
      item.jam_masuk,
      item.jam_pulang,
      item.pertemuan_ke,
      item.metode_perkuliahan,
      item.materi,
      item.kode_matakuliah,
      item.dosen_ketua,
      item.dosen_anggota,
      item.kelas,
      item.tahun_ajaran,
      item.semester,
      item.ruang,
      item.nama_matakuliah,
      item.sks
    ]);
  } catch (err) {
    console.error("Error in getDataPresensi:", err);
    throw err; // Lempar error untuk ditangkap di handler luar
  }
};
  

// Fungsi membuat pola (pattern) pada sel tabel
function drawCellPattern(doc, x, y, width, height, color) {
    doc.save();
    doc.fillColor(color); // Warna abu-abu muda untuk latar belakang sel
    doc.rect(x, y, width, height).fill();
    doc.restore();
}

const createPDF = async (data, outputPath) => {
    if (!data || data.length === 0) {
      console.log("❌ Data kosong. Pastikan file PDF memiliki isi.");
      return;
    }

    console.log("📊 Data yang diterima untuk PDF:", data); // Tambahkan log ini

    const doc = new PDFDocument({ size: "A4", margin: 1 });
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    const colWidths = [50, 100, 70, 70, 235]; // Lebar kolom
    const headers = ["PERT.", "TGL KULIAH", "MASUK", "PULANG", "PRESENSI"];
    const content = [];
    const rowHeight = 18;
    const maxRowsPerPage = 25;
    let yPosition = 50;

    // Gambar header tabel
    function drawTableHeader() {
        let xPosition = 40;
        doc.font("Helvetica-Bold").fontSize(12);
        doc.text('DAFTAR HADIR', xPosition + 5, yPosition + 5, {align: "center" });
        doc.font("Helvetica").fontSize(12);
        yPosition+=36;
        doc.text('NAMA', xPosition + 5, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
        doc.text(data[0][6], xPosition + 115, yPosition + 5, {align: "left"} );


        yPosition+=rowHeight-6;
        doc.text('NIM', xPosition + 5, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
        doc.text(data[0][5], xPosition + 115, yPosition + 5, {align: "left"} );

        yPosition+=rowHeight-6;
        doc.text('KELAS/RUANG', xPosition + 5, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
        doc.text(data[0][8], xPosition + 115, yPosition + 5, {align: "left"} );
        doc.text('/', xPosition + 165, yPosition + 5, {align: "left"} );
        doc.text(data[0][11], xPosition + 175, yPosition + 5, {align: "left"} );

        yPosition+=rowHeight-6;
        doc.text('MATA KULIAH', xPosition + 5, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
        doc.text(data[0][7], xPosition + 115, yPosition + 5, {align: "left"} );
        doc.text('SEMESTER', xPosition + 330, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
        doc.text(data[0][10], xPosition + 450, yPosition + 5, {align: "left"} );


        yPosition+=rowHeight-6;
        doc.text('DOSEN', xPosition + 5, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
        doc.text(data[0][24], xPosition + 115, yPosition + 5, {align: "left"} );
        doc.text('TAHUN AJARAN', xPosition + 330, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
        doc.text(data[0][9], xPosition + 450, yPosition + 5, {align: "left"} );

        yPosition+=rowHeight-6;
        doc.text(data[0][25], xPosition + 115, yPosition + 5, {align: "left"} );
        doc.text('SKS', xPosition + 330, yPosition + 5, {align: "left"} );
        doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
        doc.text(data[0][12], xPosition + 450, yPosition + 5, {align: "left"} );

        yPosition+=rowHeight;
        headers.forEach((header, index) => {
            drawCellPattern(doc, xPosition, yPosition, colWidths[index], rowHeight, "#D9D9D9");
            doc.rect(xPosition, yPosition, colWidths[index], rowHeight).stroke();
            doc.text(header, xPosition + 5, yPosition + 5, { width: colWidths[index] - 10, align: "center" });
            xPosition += colWidths[index];
        });
        yPosition += rowHeight;
    }

    drawTableHeader(); // Gambar header pertama kali
    doc.font("Helvetica").fontSize(12);

    let rowCount = 0;
    for (let i = 0; i < data.length; i++) {
        let xPosition = 40;

        // Jika halaman penuh, buat halaman baru
        if (rowCount >= maxRowsPerPage) {
            doc.addPage();
            yPosition = 50;
            drawTableHeader();
            doc.font("Helvetica").fontSize(12);
            rowCount = 0;
        }


        for (let j = 0 ; j < colWidths.length; j++) {
          let cellText = String(data[i][j] || "");
          console.log(`📄 Menulis ke PDF: ${cellText}`); // Tambahkan log ini
      
          // Isi sel dengan warna striping
          let genap = i % 2;
          if (genap === 0) { 
              drawCellPattern(doc, xPosition, yPosition, colWidths[j], rowHeight, "#F2F2F2");
          }    
      
          doc.rect(xPosition, yPosition, colWidths[j], rowHeight).stroke();
          doc.text(cellText, xPosition + 5, yPosition + 5, {
              width: colWidths[j] - 10,
              ellipsis: true,
              align: j === 4 ? "left" : "center"
          });
          xPosition += colWidths[j];
      }

        yPosition += rowHeight;
        rowCount++;
    }

    doc.end();
    console.log(`✅ PDF berhasil dibuat: ${outputPath}`);
}

const createPresensiReport = async (nim) => {
  const pdfFilePath = `./src/pdf/${nim}.pdf`;

  const recPresensi = await getPresensi(nim);
  console.log('📊 Data Presensi:', recPresensi);

  if (!recPresensi || recPresensi.length === 0) {
      console.error('❌ Data presensi kosong!');
      return;
  }

  await createPDF(recPresensi, pdfFilePath);
  console.log(`✅ PDF berhasil dibuat di: ${pdfFilePath}`);
};

/**
 * Membuat Presensi Kelas
 * @param {*} data 
 * @param {*} outputPath 
 * @returns 
 */

const createPresensiKelasPDF = async (data, outputPath) => {
  if (!data || data.length === 0) {
    console.log("❌ Data kosong. Pastikan file PDF memiliki isi.");
    return;
  }

  console.log("📊 Data yang diterima untuk PDF:", data); // Tambahkan log ini

  console.log('Jumlah Data: ', data[0][24]);

  const doc = new PDFDocument({ size: "A4", margin: 1 });
  const stream = fs.createWriteStream(outputPath);
  doc.pipe(stream);

  const colWidths = [35, 80, 235, 200]; // Lebar kolom
  const headers = ["NO.", "NIM", "NAMA MAHASISWA", "PRESENSI"];
  //const content = [];
  const rowHeight = 18;
  const maxRowsPerPage = 34;
  let yPosition = 50;

  function drawHeader() {
      let xPosition = 25;
      doc.font("Helvetica-Bold").fontSize(12);
      doc.text('DAFTAR HADIR MATA KULIAH', xPosition + 5, yPosition + 5, {align: "center" });
      yPosition+=rowHeight-6;
      doc.text(data[0][24].toUpperCase(), xPosition + 5, yPosition + 5, {align: "center"} );

      doc.font("Helvetica").fontSize(12);

      yPosition += rowHeight*2;

      doc.text('KELAS/PRODI', xPosition + 5, yPosition + 5, {align: "left"} );
      doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
      doc.text(data[0][20], xPosition + 115, yPosition + 5, {align: "left"} );
      doc.text('/', xPosition + 165, yPosition + 5, {align: "left"} );
      doc.text(data[0][9], xPosition + 175, yPosition + 5, {align: "left"} );
      doc.text('TAHUN AJARAN', xPosition + 330, yPosition + 5, {align: "left"} );
      doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
      doc.text(data[0][21], xPosition + 450, yPosition + 5, {align: "left"} );

      yPosition+=rowHeight-6;
      doc.text('DOSEN', xPosition + 5, yPosition + 5, {align: "left"} );
      doc.text(':', xPosition + 105, yPosition + 5, {align: "left"} );
      doc.text(data[0][18], xPosition + 115, yPosition + 5, {align: "left"} );
      doc.text('SKS', xPosition + 330, yPosition + 5, {align: "left"} );
      doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
      doc.text(data[0][25], xPosition + 450, yPosition + 5, {align: "left"} );

      yPosition+=rowHeight-6;
      doc.text(data[0][19], xPosition + 115, yPosition + 5, {align: "left"} );
      doc.text('TGL KULIAH', xPosition + 330, yPosition + 5, {align: "left"} );
      doc.text(':', xPosition + 435, yPosition + 5, {align: "left"} );
      doc.text(data[0][11], xPosition + 450, yPosition + 5, {align: "left"} );
  }

  function drawTableHeader() {
    doc.font("Helvetica-Bold").fontSize(12);
    let xPosition=25;
    yPosition+=rowHeight;
    headers.forEach((header, index) => {
        drawCellPattern(doc, xPosition, yPosition, colWidths[index], rowHeight, "#D9D9D9");
        doc.rect(xPosition, yPosition, colWidths[index], rowHeight).stroke();
        doc.text(header, xPosition + 5, yPosition + 5, { width: colWidths[index] - 10, align: "center" });
        xPosition += colWidths[index];
    });
    yPosition += rowHeight;
}  

  drawHeader(); // Gambar header pertama kali
  drawTableHeader();
  doc.font("Helvetica").fontSize(12);

  let rowCount = 0;
  let no_urut = 0;
  let tgl_cetak = true;
  for (let i = 0; i < data.length; i++) {
      let xPosition = 25;
      tgl_cetak = false;

      // Jika halaman penuh, buat halaman baru
      if (rowCount >= maxRowsPerPage) {
          tgl_cetak=true;
          yPosition+=rowHeight-15;
          doc.font("Times-Italic").fontSize(12);
          doc.text('Dicetak pada tanggal', xPosition + 5, yPosition + 5, {align: "left"} );
          doc.text(DateTimeIndonesia(new Date()), xPosition + 120, yPosition + 5, {align: "left"} );
          doc.addPage();
          yPosition = 50;
          drawTableHeader();
          doc.font("Helvetica").fontSize(12);
          rowCount = 0;
      }

      no_urut++;
      for (let j = 0 ; j < colWidths.length; j++) {
        let cellText = String(data[i][j] || "");
        console.log(`📄 Menulis ke PDF: ${cellText}`); // Tambahkan log ini
    
        // Isi sel dengan warna striping
        let genap = i % 2;
        if (genap === 0) { 
            drawCellPattern(doc, xPosition, yPosition, colWidths[j], rowHeight, "#F2F2F2");
        }    
    
        doc.rect(xPosition, yPosition, colWidths[j], rowHeight).stroke();
        doc.text(j===0?no_urut:cellText, xPosition + 5, yPosition + 5, {
            width: colWidths[j] - 10,
            ellipsis: true,
            align: j>=1 ? "left" : "center"
        });
        xPosition += colWidths[j];
    }

      yPosition += rowHeight;
      rowCount++;
  }

  // Menampilkan Kapan PDF dicetak
  if (!tgl_cetak) {
    xPosition=25;
    yPosition+=rowHeight-15;
    doc.font("Times-Italic").fontSize(12);
    doc.text('Dicetak pada tanggal', xPosition + 5, yPosition + 5, {align: "left"} );
    doc.text(DateTimeIndonesia(new Date()), xPosition + 120, yPosition + 5, {align: "left"} );
  }

  doc.end();
  console.log(`✅ PDF berhasil dibuat: ${outputPath}`);
}

const createPresensiKelasReport = async (id_kelas, tgl_kuliah, pdfFilePath) => {

//const pdfFilePath = `./src/pdf/Presensi_Kelas${id_kelas}_${tgl_kuliah}.pdf`;

const recPresensi = await getDataPresensi(id_kelas, tgl_kuliah);
console.log('📊 Data Presensi:', recPresensi);

if (!recPresensi || recPresensi.length === 0) {
    console.error('❌ Data presensi kosong!');
    return;
}

await createPresensiKelasPDF(recPresensi, pdfFilePath);
console.log(`✅ PDF berhasil dibuat di: ${pdfFilePath}`);
};

module.exports = {createPresensiReport, createPresensiKelasReport}