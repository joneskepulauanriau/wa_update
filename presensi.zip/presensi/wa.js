const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require("@whiskeysockets/baileys");
const { checkQRCode } = require('./src/model/jk_qrcode.js');
const { error } = require("console");
const {getDataRow, insertData, fetchDataWithConditions} = require('./src/model/jk_service');
const {isValidEmail, DateToWIB, DateTimeToWIB, convertToDate, getDateDifference, toDatetimeTz, timeLimit, findContent, isValidDate} = require('./src/model/jk_function');
const {createPresensiReport, createPresensiKelasReport} = require('./src/model/jk_pdfpresensi.js');
const { Session } = require("inspector/promises");
const fs = require('fs/promises');
const path = require('path');

// Fungsi memastikan folder ada atau membuatnya jika belum ada
async function ensureDirectoryExists(dir) {
    try {
        await fs.mkdir(dir, { recursive: true });
        console.log(`📂 Folder dipastikan ada: ${dir}`);
    } catch (error) {
        console.error('❌ Gagal membuat folder:', error);
    }
}

// Simpan sesi percakapan pengguna
let userSessions = {};

const getIdKelas = async () => {
    const recIdKelas = await fetchDataWithConditions(
        [
            `CONCAT('*', kelas.id_kelas, '* = ', kelas.kelas, ' ', kelas.tahun_ajaran, ' ', prodi.nama_prodi) AS id_kelas_info`,
            `kelas.kode_prodi`
        ],
        `kelas INNER JOIN prodi ON kelas.kode_prodi = prodi.kode_prodi`
    );
    return recIdKelas; 
};

const getDatamahasiswa = (nim) => {
    const recResult = fetchDataWithConditions(
        [
            `mahasiswa.nim`, 
            `mahasiswa.nama`,
            `mahasiswa.tempat_lahir`,
            `mahasiswa.tgl_lahir`,
            `mahasiswa.jenis_kelamin`,
            `kelas.id_kelas`,
            `kelas.kode_matakuliah`,
            `kelas.kelas`,
            `kelas.tahun_ajaran`,
            `kelas.kode_prodi`,
            `kelas.semester`,
            `kelas.ruang`,
            `matakuliah.nama_matakuliah`,
            `matakuliah.sks`,
            `prodi.nama_prodi`
        ],
        `kelas
        INNER JOIN matakuliah ON (kelas.kode_matakuliah = matakuliah.kode_matakuliah)
        INNER JOIN prodi ON (kelas.kode_prodi = prodi.kode_prodi)
        INNER JOIN mhskelas ON (mhskelas.id_kelas = kelas.id_kelas)
        INNER JOIN mahasiswa ON (mahasiswa.nim = mhskelas.nim)`,
        { 'mahasiswa.nim': nim }
      );
      return recResult;
}

const getDataKelas = (id_kelas) =>{
    const recResult = fetchDataWithConditions(
        [
            mahasiswa.tgl_lahir,
            mahasiswa.jenis_kelamin,
            mhskelas.id_kelas,
            mahasiswa.tempat_lahir,
            mahasiswa.nama,
            mhskelas.nim,
            kelas.kelas,
            kelas.kode_prodi,
            prodi.nama_prodi,
            kelas.kode_matakuliah,
            matakuliah.nama_matakuliah,
            matakuliah.sks,
            kelas.tahun_ajaran,
            kelas.semester,
            kelas.ruang
        ],
        `mahasiswa
        INNER JOIN mhskelas ON (mahasiswa.nim = mhskelas.nim)
        INNER JOIN kelas ON (mhskelas.id_kelas = kelas.id_kelas)
        INNER JOIN matakuliah ON (kelas.kode_matakuliah = matakuliah.kode_matakuliah)
        INNER JOIN prodi ON (kelas.kode_prodi = prodi.kode_prodi)`,
        { 'mhskelas.id_kelas': id_kelas }
      );
      return recResult;
    
} 

const getUser = (sender) => {
    const strwhere = {'no_hp':sender};
    const recResult = getDataRow ('*','pengguna', strwhere);
    return recResult;
}

// ---------------------------------------------------------------------------------

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState("./auth_multi_device"); 

    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        syncFullHistory: true,
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "close") {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log("Koneksi terputus, mencoba menyambung ulang:", shouldReconnect);
            if (shouldReconnect) startBot();
        } else if (connection === "open") {
            console.log("Bot WhatsApp terhubung!");
        }
    });

    sock.ev.on("messages.upsert", async (m) => {
        if (!m.messages[0]?.message) return;

        const msg = m.messages[0];

        // Cek apakah pesan dari bot sendiri
        if (msg.key.fromMe) return;

        const senderJid = msg.key.remoteJid;
        const senderNumber = senderJid.replace(/[@].*/, ""); // Mengambil nomor HP
        const senderName = msg.pushName || "Tanpa Nama"; 
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
        const messageType = Object.keys(msg.message)[0];

        console.log(`📩 Pesan dari ${senderName} (${senderNumber}): ${text}`);


        // Jika user dalam sesi registrasi
        if (userSessions[senderNumber]) {
            let session = userSessions[senderNumber];

            if (session.step === 1) {
                if (isNaN(text) || parseInt(text) <= 0) {
                    await sock.sendMessage(senderJid, { text: "NIM Harus Angka. Coba Lagi!" });
                    return;
                }

                // Cek Apakah NIM terdaftar sebagai mahasiswa?
                const strwhere = {nim:text};
                const recMhs = await getDataRow('*', 'mahasiswa', strwhere);
                console.log('Status data mahasiswa:', recMhs);
                if (!recMhs.success){
                    await sock.sendMessage(senderJid, { text: "Anda tidak terdaftar sebagai mahasiswa saat ini!.\n_Hubungi Admin Aplikasi ini._" });
                    delete userSessions[senderNumber];
                    return;
                }
                session.nim = text;
                session.step = 2;
                session.nama_wa = recMhs.data[0].nama;
                await sock.sendMessage(senderJid, { text: `Nama Anda *${session.nama_wa}*` });
                await sock.sendMessage(senderJid, { text: "Masukkan Email" });

            } else if (session.step === 2) {
                if (!isValidEmail(text)) {
                    await sock.sendMessage(senderJid, { text: 'Format email tidak valid. Silakan coba lagi.' });
                    return;
                }
                session.email = text;
                session.step = 3;
                await sock.sendMessage(senderJid, { text: "Masukkan Alamat:" });

            } else if (session.step === 3 ){
                session.alamat = text;
                
                // Simpan ke table pengguna
                const pengguna=[{'no_hp':senderNumber, 'nim':session.nim, 'nama_wa':session.nama_wa, 'email':session.email, 'alamat':session.alamat} ];
                const result = await insertData('pengguna', pengguna, ['no_hp']);
                console.log(result['message']);

                await sock.sendMessage(senderJid, { 
                    text: `✅ Pendaftaran sukses!\n📌 NIM: ${session.nim}\n📌 Nama: ${session.nama_wa}\n📌 Email: ${session.email}\n📌 Alamat: ${session.alamat}`
                });

                // Hapus sesi
                delete userSessions[senderNumber];

            } else if (session.step === 10) {

                console.log(messageType);
                if (messageType!=='imageMessage') {
                    await sock.sendMessage(senderJid, { text: `Anda mengirimkan ${messageType}. Kirim Gambar QRCode lagi!.` });
                    return;
                }
                const qrResult =  await checkQRCode(msg);

                if (qrResult.statusJSON){
                    
                    const existingUser = await getUser(senderNumber);
            
                    if (!existingUser['success']) {
                        await sock.sendMessage(senderJid, { text: `Halo ${senderName} Anda belum terdaftar.` });
                        delete userSessions[senderNumber];
                        return;
                    }
                    
                    const qrdata = qrResult.info;
                    const validJSON = qrdata.replace(/'/g, '"');
                    const parsedData = JSON.parse(validJSON);
                    
                    //console.log(parsedData);

                    const findResult = findContent(parsedData, /!presensi/gi);

                    if (!findResult.success){
                        await sock.sendMessage(senderJid, { text: `*QRCode* yang Anda kirim tidak mengandung informasi Presensi` });
                        return;
                    }
                    //console.log(findResult);
    
                    if (parsedData.menu==='!presensi'){
    
                        // Ambil tgl_kuliah, jam_masuk dan jam_pulang
                        const tgl_kuliah =  parsedData.tgl_kuliah;
                        const jam_masuk = parsedData.jam_masuk;
                        const jam_pulang = parsedData.jam_pulang;
                        // Rubah menjado tgl_masuk dan tgl_pulang;
                        const tgl_masuk = toDatetimeTz(tgl_kuliah, jam_masuk);
                        const tgl_pulang = toDatetimeTz(tgl_kuliah, jam_pulang);
                        console.log(tgl_masuk, tgl_pulang);
                        console.log(`Limit Tgl Masuk: ${tgl_masuk}`);
                        console.log(`Limit Tgl Keluar: ${tgl_pulang}`);
    
                        if (timeLimit(tgl_masuk) >= 0 && timeLimit(tgl_pulang) >= 0){
                            await sock.sendMessage(senderJid, { text: `Presensi tidak dapat dilakukan, karena *QRCode sudah kadaluarsa*!` });
                            return;
                        }
                        if (timeLimit(tgl_masuk) <= 0 && timeLimit(tgl_pulang) <= 0){
                            await sock.sendMessage(senderJid, { text: `Presensi belum dapat dilakukan, karena *belum waktunya*!` });
                            return;
                        }
        
                        const strwhere1 = {'id_rencana': parsedData.id_rencana};
                        const recRencana = await getDataRow ('*','rencana', strwhere1);
                        const rawNIM = existingUser.data[0].nim;
                        const jam_presensi = new Date();
                        const rawjam_presensi = jam_presensi.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
                        const rawid_rencana = recRencana.data[0].id_rencana;
                        const rawketerangan = "";
                        const rawid_presensi = 0;
    
                        // Cek Apakah Data Presensi Sudah Direkam (Bila Belum Simpan, Bila Sudah Kasih Pesan )
                        const strwhere2 = {'nim':rawNIM, 'id_rencana': parsedData.id_rencana};
                        const recPresensi = await getDataRow ('*','presensi', strwhere2);
    
                        console.log(recPresensi);
                        if (recPresensi.success){
                            await sock.sendMessage(senderJid, { text: `Anda sudah melakukan presensi pada ${recPresensi.data[0].jam_presensi.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB` });
                            delete userSessions[senderNumber];
                            return;
                        }
                        // Simpan Data Presensi
                            
                        const data_presensi =[{'id_presensi':rawid_presensi, 'nim':rawNIM, 'id_rencana': rawid_rencana, 'jam_presensi': jam_presensi, 'keterangan':rawketerangan}];
                        const recsave = await insertData('presensi', data_presensi, ['id_presensi']);
                            
                        console.log(recsave.success);
                
                        if (recsave.success) {
                            await sock.sendMessage(senderJid, { text: `Selamat! Anda berhasil melakukan presensi pada ${jam_presensi} WIB` });
                        } else {
                            await sock.sendMessage(senderJid, { text: `❌ Gagal menyimpan presensi. Coba lagi nanti.` });
                        }
                        delete userSessions[senderNumber];
                     }
                    
                } else {
                    await sock.sendMessage(senderJid, { text: `Foto yang Anda kirim tidak mengandung informasi presensi. Ulang lagi!` });
                    return;
                }

                // Hapus Sesi
                delete userSessions[senderNumber];
            }else if (session.step === 20) {
                if (isNaN(text) || parseInt(text) <= 1 || parseInt(text) >= 4) {
                    await sock.sendMessage(senderJid, { text: "ID Kelas harus angka. Coba Lagi!" });
                    return;
                }

                session.id_kelas = text;
                session.step = 21;
                await sock.sendMessage(senderJid, { text: "Masukkan tanggal kuliah\n_Format DD-MM-YYYY_ :" });
            } else if (session.step === 21) {
                if (!isValidDate(text)) {
                    await sock.sendMessage(senderJid, { text: "Format tanggal _tidak valid_. Coba lagi!" });
                    return;
                }

                session.tgl_kuliah = text;
                let pdfDir = './src/pdf';
                let pdfPath = `./src/pdf/Presensi_Kelas${session.id_kelas}_${session.tgl_kuliah}_${senderName}.pdf`
                await sock.sendMessage(senderJid, { text: "Tunggu sebentar! lagi proses..." });

                try {
                    // Pastikan folder ./src/pdf ada
                    await ensureDirectoryExists(pdfDir);
        
                    // Hapus file PDF lama jika ada
                    try {
                        await fs.unlink(pdfPath);
                        console.log(`🗑️ File PDF lama dihapus: ${pdfPath}`);
                    } catch (unlinkError) {
                        if (unlinkError.code !== 'ENOENT') {
                            console.error('❌ Gagal menghapus file PDF lama:', unlinkError);
                        }
                    }
        
                    // Buat file PDF baru
                    await createPresensiKelasReport(session.id_kelas, session.tgl_kuliah, pdfPath);
                    console.log(`✅ PDF berhasil dibuat: ${pdfPath}`);
        
                    // Tunggu hingga file benar-benar dibuat
                    let isFileReady = false;
                    for (let i = 0; i < 10; i++) {
                        try {
                            await fs.access(pdfPath);
                            isFileReady = true;
                            break;
                        } catch {
                            console.log('⏳ Menunggu file PDF siap...');
                            await new Promise((resolve) => setTimeout(resolve, 500));
                        }
                    }
        
                    if (!isFileReady) {
                        throw new Error('File PDF tidak ditemukan setelah dibuat.');
                    }
        
                    // Baca dan kirim PDF
                    const pdfBuffer = await fs.readFile(pdfPath);
                    await sock.sendMessage(senderJid, {
                        document: pdfBuffer,
                        mimetype: 'application/pdf',
                        fileName: `Presensi_Kelas${session.id_kelas}_${session.tgl_kuliah}_${senderName}.pdf`
                    });
        
                    console.log('📄 PDF berhasil dikirim ke:', senderJid);
                } catch (error) {
                    console.error('❌ Error saat membuat/mengirim PDF:', error);
                    await sock.sendMessage(senderJid, { text: 'Gagal membuat atau menemukan file PDF.' });
                }
                // Hapus Sesi
                delete userSessions[senderNumber];

            } 
            return;
        }

        console.log(messageType);

        // Mengabaikan selain teks
        if (messageType==='conversation') {
            
            // Jika user mengetik "!presensi"
            if (text.toLowerCase() === "!presensi") {
                const existingUser = await getUser(senderNumber);
        
                if (!existingUser['success']) {
                    await sock.sendMessage(senderJid, { text: `Anda *${existingUser.data[0].nama_wa}* belum terdaftar.` });
                } else {
                    userSessions[senderNumber] = { step: 10 }; // Mulai sesi presensi
                    session.loop = 1;
                    await sock.sendMessage(senderJid, { text: "Kirim Foto QRCode yang disediakan:" });
                }
                return;
            }

            // Jika user mengetik "!daftar"
            if (text.toLowerCase() === "!daftar") {
                const existingUser = await getUser(senderNumber);
        
                if (existingUser['success']) {
                    await sock.sendMessage(senderJid, { text: `Anda sudah terdaftar sebagai *${existingUser.data[0].nama_wa}*.` });
                } else {
                    userSessions[senderNumber] = { step: 1 }; // Mulai sesi pendaftaran
                    await sock.sendMessage(senderJid, { text: "Masukkan NIM:" });
                }
                return;
            }

            // Jika user mengetik "!custpresensi"
            if (text.toLowerCase() === "!custpresensi") {
                const existingUser = await getUser(senderNumber);
        
                if (existingUser['success']) {
                    userSessions[senderNumber] = { step: 20 }; // Mulai sesi pendaftaran
                    // Baca ID Kelas
                    const recIdKelas = await getIdKelas();
                    if (recIdKelas.length===0){
                        console.log('Data ID Tidak Ada...');
                        return;
                    }
                    let strIdKelas = 'Berikut ini *ID Kelas* yang tersedia:\n\n';
                    for(let i=0;i<recIdKelas.length;i++){
                        strIdKelas=strIdKelas+'_'+recIdKelas[i].id_kelas_info+'_\n';
                    }
                    strIdKelas=strIdKelas+'\nMasukkan ID Kelas :';
                    await sock.sendMessage(senderJid, { text: strIdKelas });
                } else {
                    await sock.sendMessage(senderJid, { text: `Anda sudah terdaftar sebagai *${existingUser.data[0].nama_wa}*.` });
                }
                return;
            }

            // Jika user mengetikan "!listpresensi"
            if (text.toLowerCase() === '!listpresensi') {
                
                try {
                    const existingUser = await getUser(senderNumber);
                    if (!existingUser.success) throw new Error("Pengguna tidak ditemukan");

                        //if (!existingUser['success']) {
                        //    await sock.sendMessage(senderJid, { text: `Halo ${senderName}, Anda belum terdaftar.` });
                        //} else {
                        const strwhere3 = { 'nim': existingUser.data[0].nim };
                        const recPresensiList = await fetchDataWithConditions(['*'], 'presensi', strwhere3);

                        console.log(recPresensiList.length);

                        if (recPresensiList.length === 0) {
                            await sock.sendMessage(senderJid, { text: `⚠️ Anda belum memiliki data presensi.` });
                            return;
                        }
                        const pdfDir = './src/pdf';
                        const pdfPath = path.join(pdfDir, `${existingUser.data[0].nim}.pdf`);
                        await sock.sendMessage(senderJid, { text: `Tunggu sebentar lagi proses...` });
            
                    try {
                        // Pastikan folder ./src/pdf ada
                        await ensureDirectoryExists(pdfDir);
            
                        // Hapus file PDF lama jika ada
                        try {
                            await fs.unlink(pdfPath);
                            console.log(`🗑️ File PDF lama dihapus: ${pdfPath}`);
                        } catch (unlinkError) {
                            if (unlinkError.code !== 'ENOENT') {
                                console.error('❌ Gagal menghapus file PDF lama:', unlinkError);
                            }
                        }
            
                        // Buat file PDF baru
                        await createPresensiReport(existingUser.data[0].nim);
                        console.log(`✅ PDF berhasil dibuat: ${pdfPath}`);
            
                        // Tunggu hingga file benar-benar dibuat
                        let isFileReady = false;
                        for (let i = 0; i < 10; i++) {
                            try {
                                await fs.access(pdfPath);
                                isFileReady = true;
                                break;
                            } catch {
                                console.log('⏳ Menunggu file PDF siap...');
                                await new Promise((resolve) => setTimeout(resolve, 500));
                            }
                        }
            
                        if (!isFileReady) {
                            throw new Error('File PDF tidak ditemukan setelah dibuat.');
                        }
            
                        // Baca dan kirim PDF
                        const pdfBuffer = await fs.readFile(pdfPath);
                        await sock.sendMessage(senderJid, {
                            document: pdfBuffer,
                            mimetype: 'application/pdf',
                            fileName: `${existingUser.data[0].nim}.pdf`
                        });
            
                        console.log('📄 PDF berhasil dikirim ke:', senderJid);
                    } catch (error) {
                        console.error('❌ Error saat membuat/mengirim PDF:', error);
                        await sock.sendMessage(senderJid, { text: 'Gagal membuat atau menemukan file PDF.' });
                    }
                //}
                    return;
                }catch (err) {
                    console.error("❌ Terjadi kesalahan:", err.message);
                    await sock.sendMessage(senderJid, { text: "⚠️ Terjadi kesalahan sistem. Silakan coba lagi nanti." });
                }
            }


            // Jika user sudah terdaftar
            const dbUser = await getUser(senderNumber);

            if (dbUser['success']) {
                const [dbMhs] = await getDatamahasiswa(dbUser.data[0].nim)
                
                console.log(`Sender : ${dbMhs.nama}`);

                await sock.sendMessage(senderJid, { 
                    text: `Halo *${dbUser['data'][0]['nama_wa']}* 👋!\nData Anda:\n📌 NIM: ${dbUser['data'][0]['nim']}\n📌 Nama: ${dbUser['data'][0]['nama_wa']}\n📌 Alamat: ${dbUser['data'][0]['alamat']}` 

                });
            } else {
                await sock.sendMessage(senderJid, { 
                    text: `Halo ${senderName}, Anda belum terdaftar.\nKetik *!daftar* untuk mendaftar.` 
                });
            }
        }
        
        if (messageType==='imageMessage'){

            try {
                const qrResult =  await checkQRCode(msg);
            
                //console.log('Status JSON', qrResult.statusJSON);
                //const statusJSON = is()
    
                if (qrResult.statusJSON){
                    const qrdata = qrResult.info;
                    const validJSON = qrdata.replace(/'/g, '"');
                    const parsedData = JSON.parse(validJSON);
                    console.log(parsedData);
                    const findResult = findContent(parsedData, /!presensi/gi);
    
                    if (!findResult.success){
                        await sock.sendMessage(senderJid, { text: `*QRCode* yang Anda kirim tidak mengandung informasi Presensi` });
                        return;
                    }
                    //console.log(findResult);
    
                    if (parsedData.menu==='!presensi'){
    
                        // Ambil tgl_kuliah, jam_masuk dan jam_pulang
                        const tgl_kuliah =  parsedData.tgl_kuliah;
                        const jam_masuk = parsedData.jam_masuk;
                        const jam_pulang = parsedData.jam_pulang;
                        // Rubah menjado tgl_masuk dan tgl_pulang;
                        const tgl_masuk = toDatetimeTz(tgl_kuliah, jam_masuk);
                        const tgl_pulang = toDatetimeTz(tgl_kuliah, jam_pulang);
                        console.log(tgl_masuk, tgl_pulang);
                        console.log(`Limit Tgl Masuk: ${tgl_masuk}`);
                        console.log(`Limit Tgl Keluar: ${tgl_pulang}`);
    
                        if (timeLimit(tgl_masuk) >= 0 && timeLimit(tgl_pulang) >= 0){
                            await sock.sendMessage(senderJid, { text: `Presensi tidak dapat dilakukan, karena *QRCode sudah kadaluarsa*!` });
                            return;
                        }
                        if (timeLimit(tgl_masuk) <= 0 && timeLimit(tgl_pulang) <= 0){
                            await sock.sendMessage(senderJid, { text: `Presensi belum dapat dilakukan, karena *belum waktunya*!` });
                            return;
                        }
        
                        const existingUser = await getUser(senderNumber);
    
                        if (!existingUser['success']) {
                            await sock.sendMessage(senderJid, { text: `Halo ${senderName}, Anda belum terdaftar.` });
                        } else {
                            const strwhere1 = {'id_rencana': parsedData.id_rencana};
                            const recRencana = await getDataRow ('*','rencana', strwhere1);
                            const rawNIM = existingUser.data[0].nim;
                            const jam_presensi = new Date();
                            const rawjam_presensi = jam_presensi.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
                            const rawid_rencana = recRencana.data[0].id_rencana;
                            const rawketerangan = "";
                            const rawid_presensi = 0;
    
                            // Cek Apakah Data Presensi Sudah Direkam (Bila Belum Simpan, Bila Sudah Kasih Pesan )
                            const strwhere2 = {'nim':rawNIM, 'id_rencana': parsedData.id_rencana};
                            const recPresensi = await getDataRow ('*','presensi', strwhere2);
    
                            console.log(recPresensi);
                            if (recPresensi.success){
                                await sock.sendMessage(senderJid, { text: `Anda sudah melakukan presensi pada ${recPresensi.data[0].jam_presensi.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB` });
                                return;
                            }
                            // Simpan Data Presensi
                            
                            const data_presensi =[{'id_presensi':rawid_presensi, 'nim':rawNIM, 'id_rencana': rawid_rencana, 'jam_presensi': jam_presensi, 'keterangan':rawketerangan}];
                            const recsave = await insertData('presensi', data_presensi, ['id_presensi']);
                            
                            console.log(recsave.success);
                
                            await sock.sendMessage(senderJid, { text: `Selamat Anda berhasil melakukan presensi pada ${rawjam_presensi} WIB`});
                        }
                    }    
                }else{
                    await sock.sendMessage(senderJid, { text: `*QRCode* yang Anda kirim tidak mengandung informasi Presensi` });
                }
            }
            catch (err) {
                console.log('Terjadi kesalahan....');
            }
            return;
        }

    });

    return sock;
}

startBot();
